import React from 'react';
import { motion } from 'framer-motion';

const FloatingElements = () => {
  const elements = [
    { size: 60, x: '10%', y: '20%', delay: 0 },
    { size: 40, x: '80%', y: '30%', delay: 0.5 },
    { size: 80, x: '15%', y: '70%', delay: 1 },
    { size: 50, x: '85%', y: '80%', delay: 1.5 },
    { size: 30, x: '50%', y: '10%', delay: 2 },
    { size: 70, x: '70%', y: '60%', delay: 2.5 },
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {elements.map((element, index) => (
        <motion.div
          key={index}
          className="absolute rounded-full bg-gradient-primary opacity-10"
          style={{
            width: element.size,
            height: element.size,
            left: element.x,
            top: element.y,
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ 
            scale: 1, 
            opacity: 0.1,
            y: [0, -20, 0],
          }}
          transition={{
            duration: 1,
            delay: element.delay,
            y: {
              duration: 4 + Math.random() * 2,
              repeat: Infinity,
              ease: "easeInOut"
            }
          }}
        />
      ))}
      
      {/* Animated particles */}
      <div className="absolute inset-0">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-primary rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 3,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default FloatingElements;